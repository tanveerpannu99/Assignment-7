﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TollEntrySystem.Models
{
    public class VehicleDetail
    {
        public int ID { get; set; }
        public string VehicleNo { get; set; }
        public string VehicleType { get; set; }
        public string Model { get; set; }
        public Nullable<int> Price { get; set; }

        public List<Customer> Customers { get; set; }

    }
}
